mqtt_broker_configs = {
    "HOST" : "broker.emqx.io",
    "PORT": 1883,
    "CLIENT_NAME" : "client_project",
    "KEEPALIVE": 60,
    "TOPIC": "/esteiraapi"
}

#configuração do broker para fazer a conexão 