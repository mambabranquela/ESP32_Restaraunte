from API_REDES.main.main import start
#If para rodar o main
if __name__ == "__main__":
    start() 